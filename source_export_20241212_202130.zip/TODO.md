# To-Do List

- [x] Add actual implementation of people classes.
- [ ] Add a story
- [x] Add quests
- [x] Add full dialogue system
