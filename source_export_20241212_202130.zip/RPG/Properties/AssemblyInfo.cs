using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("RPG")]
[assembly: AssemblyDescription("A simple RPG game.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Independent")]
[assembly: AssemblyProduct("RPG")]
[assembly: AssemblyCopyright("Copyright © 2024 Jacob Walton")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(false)]
[assembly: Guid("2f92d0a4-fe17-4af0-8b61-059589352572")]
[assembly: AssemblyVersion("0.1.0.0")]
[assembly: AssemblyFileVersion("0.1.0.0")]
[assembly: AssemblyInformationalVersion("0.1.0")]
